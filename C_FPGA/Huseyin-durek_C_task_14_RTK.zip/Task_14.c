/*
 * "Hello World" example.
 *
 /*
 * "Hello World" example.
 *
 * This example prints 'Hello from Nios II' to the STDOUT stream. It runs on
 * the Nios II 'standard', 'full_featured', 'fast', and 'low_cost' example
 * designs. It runs with or without the MicroC/OS-II RTOS and requires a STDOUT
 * device in your system's hardware.
 * The memory footprint of this hosted application is ~69 kbytes by default
 * using the standard reference design.
 *
 * For a reduced footprint version of this template, and an explanation of how
 * to reduce the memory footprint for a given application, see the
 * "small_hello_world" template.
 *
 */

#include <altera_avalon_sierra_ker.h>
#include <stdio.h>
#include<draw_vga.h>
#include<io.h>
#include <altera_avalon_pio_regs.h>
#include<system.h>
#include<de10_lite_vga_driver.h>
#include<de10_lite_Arduino_driver.h>
#include <stdbool.h>


#define STACK_SIZE 800
#define SEM_SHARED_DATA 1


// Task identifiers
#define IDLE 0
#define TASK_TIMER 1
#define TASK_ACC 2
#define TASK_ACC_FILTER 3
#define TASK_PLOT 4
//----------------------------
	typedef struct position
		{
			int16_t x;
			int16_t y;
			int16_t z;
		}postion_t;
postion_t global_acc_data;


//-------------------------------------
// Task stacks
#define STACK_SIZE 800
char idle_stack[STACK_SIZE];
char timer_stack[STACK_SIZE];
char acc_stack[STACK_SIZE];
char acc_filter_stack[STACK_SIZE];
char plot_stack [STACK_SIZE];
//----------------------------------
/* *Denna funktion rensar sk�rmen genom att skriva f�rgv�rdet till alla pixlar p� sk�rmen.
   *param f�rg F�rg att fylla sk�rmen med.
 */

void clear_screen_range (size_t x0,size_t y0,size_t x1,size_t y1);

//---------------------------------------------
void idle_task_code(void)
{
	int i=0;
	printf("idel start\n");
  /* Never blocked. Idle is only in running or ready state, lowest priority and taskid 0 */
  while (1) // loop forever
  {
   for ( i = 0; i < 500000; i++); // delay between printing dots
    printf("\nIDEL");
  }
}

//-----------------------------------------------------
//R�knar tid p� period.Uppdatera global time och visar r�kning v�rde p� sk�rmen
void timer_task_code(void)
{
	//att anv�nda deadline ingen extera exvirring eller svar tid att hantera.
	task_periodic_start_union deadline;//// sierra-timer.h under meny driver.
	init_period_time(50);// 1 scond(50mHZ period (0,02sec)*50=1 sec)

	const char timer_task[]="timer_task"; //kostant f�r timer
	unsigned int time=-0;

  while (1)
  {
	  deadline=wait_for_next_period();
      if (deadline.periodic_start_integer &0x1)
		  {
    	  printf("\ndeadline miss, timer task\n");
		  }
      //r�kna upp tid second
      time++;
      //skriv ut sk�rmen fr�n biblotek p� <draw_vga.h>.tty �r ett vga driver.
      tty_print(70, 140,timer_task, Col_White, Col_Black);//70x 0ch 165y kordinaten,task_name  �r constant variable,f�rgkod.
      // kordinaten f�r timer.det �r r�knare variable
      int_print(70, 165, time, 5, Col_White, Col_Black);// 70 0ch 165 kordinaten,time �r r�knare variable,5 �r antal sifror(01234),f�rgkod.


  }
}

//-----------------------------------------------------
void task_acc_code(void)
{
	   // uint32_t seconds = 0;
		task_periodic_start_union deadline;// en timer mackro fr�n siera
		init_period_time(50);// 1 scond(50mHZ period (0,02sec)*50=1 sec)

		postion_t  local_acc_data;

	  while (1)
	  {
		      deadline=wait_for_next_period();
			  if (deadline.periodic_start_integer &0x1)
			  {
				 printf("deadline miss, task ACC \n");
			  }
			  /**accelerometer_receive; Ta emot aktuella accelerometerv�rden. Den m�ste ha �ppnats och initierats f�rst.
			   *param accelerometer_x Pekare till 16-bitars heltal som anv�nds f�r att lagra x-v�rdet.
			   *param accelerometer_y Pekare till 16-bitars heltal som anv�nds f�r att lagra y-v�rde.
			   *param accelerometer_z Pekare till 16-bitars heltal som anv�nds f�r att lagra z-v�rdet.
			   *return 1 om det lyckas, annars 0.
			  */
		  accelerometer_receive(&local_acc_data.x,&local_acc_data.y,&local_acc_data.z);
		  sem_take(SEM_SHARED_DATA);
		  global_acc_data=local_acc_data;
		  sem_release(SEM_SHARED_DATA);
		  /*    *Skriver ut en str�ng p� sk�rmen bokstav f�r bokstav.
		        *param x0 Det �vre v�nstra h�rnet horisontellt l�ge. Om den �r negativ kommer str�ngen att besk�ras delvis.
		        *param y0 Det �vre v�nstra h�rnet vertikalt l�ge. Om den �r negativ kommer str�ngen att besk�ras delvis.
		        *param sz_tty ASCII-tecken som ska skrivas ut.
		        *param f�rg F�rg att anv�nda f�r tecknen.
		        *param BGcolor F�rg att anv�nda f�r bakgrunden f�r karakt�rerna.
		  */
		  tty_print(60, 40, "task_Acc", Col_White, Col_Black);
	//-----------------------------------------------------
		  tty_print(60, 50, "x", Col_White, Col_Black);//
		  //print x
		  int_print(70,50,local_acc_data.x,3,Col_White, Col_Black);
	//-------------------------------------------------
		  tty_print(60, 60, "y", Col_White, Col_Black);//
		  //print y
		  int_print(70,60,local_acc_data.y,3,Col_White, Col_Black);
	//-----------------------------------------------------------
		  tty_print(60, 70, "z", Col_White, Col_Black);
		  //print z
		  int_print(70,70,local_acc_data.z,3,Col_White, Col_Black);

	}
}
//-----------------------------------------------------
void task_acc_filter_code(void)
{
	task_periodic_start_union deadline;
	init_period_time(50);// 1 scond(50mHZ period (0,02sec)*50=1 sec)
	postion_t acc_array[10];//l�ser 10 g�nger

	int counter=0;
	bool sampled_ten_times=false;// om tio g�ngar ska vara  noll
	int avg_x=0;
	int avg_y=0;
	int avg_z=0;

	  while (1)
	  {
			deadline=wait_for_next_period();

			if (deadline.periodic_start_integer&0x1)
			{
				printf("deadline miss,task ACC FILTER");
			}
		    tty_print(200,40,"task_acc_filter",Col_White, Col_Black);
		    sem_take(SEM_SHARED_DATA);// samlar information
		    acc_array[counter]=global_acc_data;
		    sem_release(SEM_SHARED_DATA);
     //  clear_screem_range (170,0,319,110);
		    if (sampled_ten_times)// false

		    {
				 avg_x=0;
				 avg_y=0;
				 avg_z=0;
				 for(size_t i=0; i<10; i++)
				 {
					avg_x+=acc_array[i].x;// varje g�ng r�knar upp till 10 g�ngar
					avg_y+=acc_array[i].y;
					avg_z+=acc_array[i].z;
				 }
				//Den sampel v�rde dela upp 10 f�r att hitta medel v�rde.
				 avg_x/=10; //avgx= avgx/10
				 avg_y/=10;
				 avg_z/=10;
				 tty_print(230,60,"x",Col_White,Col_Black);//skriv ut variable postion p� vga sk�rmen
				 int_print(240,60,avg_x,3, Col_White,Col_Black);
	//---------------------------------------------------
				 tty_print(230,70,"y",Col_White,Col_Black);
				 int_print(240,70,avg_y,3, Col_White,Col_Black);
	//-----------------------------------------------------------
				 tty_print(230,80,"z",Col_White,Col_Black);
				 int_print(240,80,avg_z,3, Col_White,Col_Black);
		    }
		    else if(counter==9)
			{
		    	sampled_ten_times=true;
			}

		    counter=(counter+1)%10;//r�knar upp 1  sen delar upp 10 det blir noll den ska vara index vilkoret(if).

	  }
}

//-----------------------------------------------------
void task_plot_code(void)

{  task_periodic_start_union deadline;
	init_period_time(50);// 1 scond(50mHZ period (0,02sec)*50=1 sec)
	//postion_t acc_array[10];//l�ser 10 g�nger
	postion_t  local_pos;

	int counter=0;




	 int couter=0;
	 while (1)
	  {
			deadline=wait_for_next_period();

			if (deadline.periodic_start_integer&0x1)
			{
				printf("deadline miss,task ACC plot");
			}

			if (counter==0)
			{
				clear_screen_range(170,125,319,239);// om caunter lika 5 p� sk�rmen rensar
			}
			tty_print(200,140,"task_acc_plot",Col_White, Col_Black);//position av task namnet

		    sem_take(SEM_SHARED_DATA);// samlar information
		    local_pos=global_acc_data;
		    sem_release(SEM_SHARED_DATA);


//----------------------------------------------------------------------------
		    tty_print(185,180,"Z0",Col_White,Col_Black);//z linje
		    draw_hline(210,180,100,Col_Cyan);//x linje

		    /*  *y kordinaten visar som z v�rde f�r accelemat�r
				*x kordinaten visar som tid
	
				*180+((local_pos.z /8)*(-1)) 180 z position sumeras acccelerametor pos
				*Ex:local variable max 255/8+180=212 ger minimum punk f�r plot p� vga sk�rm
				*Dela 8  f�r att anv�nda vaga platsen effektiv
				*Mupisera -1  h�lla star postion uppe postion
				*1 �r radia
		    */
		    draw_filled_circle(205+(5*(counter)),180+((local_pos.z /8)*(-1)),1,Col_Green);
		    counter=(counter + 1)% 20;//caunter r�kna upp 20 sen borja  igen
       }
}



//-----------------------------------------------------
int main (void)
{
	clear_screen(Col_Black);
    tty_print(120,5,"Huseyin_Durek",Col_White,Col_Black);
	tty_print(180,130,"press any button",Col_White,Col_Black);
	int button=3;
	while (button==3)
	{
		button= 0X3& IORD_ALTERA_AVALON_PIO_DATA(PIO_BUTTONS_IN_BASE);
	}
  sierra_initiation_HW_and_SW();
 // sierra_print_versions();
  printf("Sierra HW version=%d\n",sierra_HW_version());
  printf("Sierra Sw driver version=5d\n",sierra_SW_driver_version());

	      while(!accelerometer_open_dev())
		    {
		    	printf("we were  not able  to open accelerometer,please seek help\n");
		    }
		    while(!accelerometer_init())
		    {
		    	printf("we were  not able  to initate accelerometer,please seek help\n");
		    }
	      /* *Ritar en horisontell linje med angiven l�ngd. Funktionen kan misslyckas om den inte �r begr�nsad till sk�rmen.
	         * param x0 Horisontell start av linjen.
	         *param y0 Vertikal start av raden.
	         *param l�ngd Horisontellt avst�nd f�r linjen - linjen slutar p� (x0+l�ngd, y0)
	         *param f�rg F�rg p� linjen.
	      */
	      
	      /// x line
	      draw_hline( 0, 20,  CANVAS_WIDTH-1, Col_White);  //upp linje f�r horisantal
	      draw_hline(0,120,CANVAS_WIDTH-1,Col_White);// mitt linje f�r horisantal
	      // y line
	      draw_vline(160,20,CANVAS_WIDTH-1,Col_White);//mitt vertikal



  /*********************************************************************
   * Initialize time base register.
   * This example     : 50 MHz system-clock
   * Wanted tick time : 20 ms (50Hz)
   * Formula gives    : 20 ms x 50 MHx / 1000 => 1000(dec)
   * ******************************************************************/
  sierra_set_timebase(1000);

  sierra_create_task(IDLE, 0,READY_TASK_STATE, idle_task_code, idle_stack, STACK_SIZE);
  sierra_create_task(TASK_TIMER, 1, READY_TASK_STATE, timer_task_code, timer_stack, STACK_SIZE);
  sierra_create_task(TASK_ACC , 1, READY_TASK_STATE, task_acc_code, acc_stack, STACK_SIZE);
  sierra_create_task(TASK_ACC_FILTER , 1, READY_TASK_STATE, task_acc_filter_code, acc_filter_stack, STACK_SIZE);
  sierra_create_task(TASK_PLOT , 1, READY_TASK_STATE, task_plot_code, plot_stack, STACK_SIZE);

  // Start the Sierra scheduler
  sierra_tsw_on(); // enable CPU irq from Sierra and now at least idle task will trigger an IRQ.

  while (1)
  {
    // Should never end up here...!
    printf ("* ERROR! SYSTEM FAILED *\n ");
  }

  return 0;
}
//-----------------funktion f�r clear
void clear_screen_range (size_t x0,size_t y0,size_t x1,size_t y1)

{
	for( size_t x= x0; x<=x1; x++)
	{
		for (size_t y=y0; y<=y1 ; y++)
		{
			write_pixel(x,y,Col_Black);
		}
	}
}

