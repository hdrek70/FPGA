/*


 * -- Company: TEIS AB
   -- Engineer: Huseyin Durek

      ----BSP Description

BSP Type: hal
CPU: cpu
BSP Generated On: 2023-aug-18 18:05:07
BSP Generated Timestamp: 1692378307111

   	   --- Program fuktion
	Ett timer som validerar driver.
	Variabel SECOND och MINUTES
	Kounter r�knar till 59 printf skriv ut  SECOND noll MINUTES 1.
	Den loopp �r oendlig.
 */
#include <stdio.h>////includera base address defintions
#include <io.h>   //includera HAL macros
#include "altera_avalon_timer_regs.h"//driver

int main() {
	int second = 0;// int variable star med noll
	int minutes = 0;// int variable star med noll
	TIMER_RESET;   // include "altera_avalon_timer_regs.h" bibliotek variabler
	TIMER_START;

	//o�ndlig lop
	while (1) {
		while (TIMER_READ < 50000000);//Fpga klocks frekvens �r 50MHZ dvs en period �r 0,2 mikro second.Beh�va v�nta 50 miljon klock cyckel f�r att skaffa 1 second.

		TIMER_RESET;
		TIMER_START;
		if (++second < 60){
			printf("second=%d\n", second);// om  variable second r�knar till 59 skriver ut
		}
		else {
			minutes++;
			second = 0;
			printf("minutes=%d\n", minutes);// �ver 59 variable second  skriver ut noll  och minut r�knar upp
		}
	}

	return 0;
}
