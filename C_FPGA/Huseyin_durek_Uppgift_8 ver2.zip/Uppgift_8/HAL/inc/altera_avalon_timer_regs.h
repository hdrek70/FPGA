#ifndef ALTERA_AVALON_TIMER_REGS_H_		//om denna fil har l�sts av l�nken tidigare, kommer
#define ALTERA_AVALON_TIMER_REGS_H_		//l�nken att hoppa �ver alla rader tills n�sta #endif
#include <io.h>			//includera HAL macros
#include <system.h>			//includera base address defintions
//define device driver macros
#define TIMER_STOP IOWR_32DIRECT(TIMER_HW_IP_0_BASE,4,0x00000000)	// skriva till kontrollregistret
#define TIMER_RESET IOWR_32DIRECT(TIMER_HW_IP_0_BASE,4,0x40000000)	// skriva till kontrollregistret
#define TIMER_START IOWR_32DIRECT(TIMER_HW_IP_0_BASE,4,0x80000000)	// skriva till kontrollregistret
#define TIMER_READ IORD_32DIRECT(TIMER_HW_IP_0_BASE,0)	// l�sa fr�n data register

#endif 	//ALTERA_AVALON_TIMER_REGS_H_
//This ends the #ifndef

