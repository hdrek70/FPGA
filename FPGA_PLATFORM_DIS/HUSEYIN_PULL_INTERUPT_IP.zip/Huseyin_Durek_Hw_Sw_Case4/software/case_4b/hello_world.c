/*
 * "Hello World" example.
 *
 * This example prints 'Hello from Nios II' to the STDOUT stream. It runs on
 * the Nios II 'standard', 'full_featured', 'fast', and 'low_cost' example
 * designs. It runs with or without the MicroC/OS-II RTOS and requires a STDOUT
 * device in your system's hardware.
 * The memory footprint of this hosted application is ~69 kbytes by default
 * using the standard reference design.
 *
 * For a reduced footprint version of this template, and an explanation of how
 * to reduce the memory footprint for a given application, see the
 * "small_hello_world" template.
 *
 */
#include <stdio.h>
#include<alt_types.h>
#include<altera_avalon_pio_regs.h>
#include<io.h>
#include<sys/alt_irq.h>
#include<system.h>
#include<stdio.h>

void handle_button_interrupt(void*pContex);// declera funktion
static int count_button=0;  // Global counter deklration.

int main()
{
	int*pContex=NULL;
	printf("vi start.\n");
	//IOWR_ALTERA_AVALON_PIO_IRQ_MASK(PIO_INTERRUPT_BASE,0X1);//inaktive sw1 dvs vi v�ljer den h�r knappen
	IOWR_ALTERA_AVALON_PIO_IRQ_MASK(PIO_INTERRUPT_BASE,0X1);//ta bort i v�nta p� interupt.Dvs vi har l�st denna knapt .


	// alt_ic_isr_register() kan anv�ndas f�r att registrera en avbrottshanterare.
	//Om funktionen �r framg�ngsrik, kommer det beg�rda avbrottet att aktiveras
	//PIO_IRQ_INTERRUPT_CONTROLLER_ID,uppgift �r koplar till interupt konttoroller.D�rf�r det finns olika kopling till olika komponenten.
	//den h�r komponnet skickar intrupt(PIO_INTERRUPT_IRQ)
	//Vilken funktion (handle_button_interrupt)
	//pcontex skickar funktionnen till interupt service rutin

	if(alt_ic_isr_register(PIO_INTERRUPT_IRQ_INTERRUPT_CONTROLLER_ID,PIO_INTERRUPT_IRQ,handle_button_interrupt,pContex,0x1))
		printf("Eror register IRQ handeler\n");

				printf("wait for key to be pressed down\n");
				IOWR_ALTERA_AVALON_PIO_IRQ_MASK(PIO_INTERRUPT_BASE,0X1);
				printf("wait for key be pressed down\n");//sw1 aktiv som interupt.
	while(1)
	{
		printf("Counts:%d\n",count_button);
		IOWR_16DIRECT(PIO_INTERRUPT_BASE,0,count_button);
		for (size_t i=0; i <1000000; ++i);

	}


  return 0;
}
// Cpu k�r den funktionen
		void handle_button_interrupt(void*pContex)// definera funktion
		{
			printf("IRQ!\n");
			count_button=(count_button +1)& 0xf;
			IOWR_ALTERA_AVALON_PIO_EDGE_CAP(PIO_INTERRUPT_BASE,0X1);
			IORD_ALTERA_AVALON_PIO_EDGE_CAP(PIO_INTERRUPT_BASE);
		}
