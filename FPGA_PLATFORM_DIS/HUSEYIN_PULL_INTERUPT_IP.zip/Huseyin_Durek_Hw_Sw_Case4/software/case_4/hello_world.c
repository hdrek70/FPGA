/*
 * "Hello World" example.
 *
 * This example prints 'Hello from Nios II' to the STDOUT stream. It runs on
 * the Nios II 'standard', 'full_featured', 'fast', and 'low_cost' example
 * designs. It runs with or without the MicroC/OS-II RTOS and requires a STDOUT
 * device in your system's hardware.
 * The memory footprint of this hosted application is ~69 kbytes by default
 * using the standard reference design.
 *
 * For a reduced footprint version of this template, and an explanation of how
 * to reduce the memory footprint for a given application, see the
 * "small_hello_world" template.
 *
 */

#include <stdio.h>
#include<system.h>
#include<io.h>
#include <altera_avalon_pio_regs.h>
#include<sys/alt_irq.h>

int button_val=0;//den vriable  hanlar om vilken tilst�nd p� knapp
int count_val=0; // den vriable  hanlar om vilken caunter valu



int main()
{

	while(1)
	{
		button_val=IORD_ALTERA_AVALON_PIO_DATA(PIO_POLL_BASE);//l�ser fr�n knapp adressen och sparar knap information p� variable som �r button pio.
			  if((button_val &0x1)== 0)
			  {
				  printf("button_pressed,count_val=%d\n",count_val);  //skriv ut r�knade v�rdet
				  if (count_val>=15)//tryck button 0
					  count_val=0; //n�r r�knar max 15 det blir noll
				  else
					  count_val+=3;// varje g�ng r�knar 3

			  }
			  while(button_val==0)
			  {
				  button_val=IORD_ALTERA_AVALON_PIO_DATA(PIO_POLL_BASE)&0X1;
			  }
			  for (int i =0;i<500000; i++ );
	}

}
