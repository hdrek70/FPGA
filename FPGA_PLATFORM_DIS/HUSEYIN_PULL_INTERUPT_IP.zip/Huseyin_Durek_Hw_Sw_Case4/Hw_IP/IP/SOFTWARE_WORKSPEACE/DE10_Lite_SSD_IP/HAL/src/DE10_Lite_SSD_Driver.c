/**
 * \file       DE10_Lite_SSD_Driver.c
 * \details    Functions for enabling and writing to Seven Segment displays.
 * \author     Linus Eriksson
 * \author     Jens Lind
 * \version    2.0
 * \date       2017-2021
 * \copyright  AGSTU AB
 */

#include <system.h>
#include <io.h>

#include "DE10_Lite_SSD_Driver.h"

extern void ssd_enable(uint8_t displays)
{
	IOWR_32DIRECT(DE10_LITE_SSD_IP_0_BASE, 0, displays);
}

extern void ssd_write(uint8_t display, uint8_t value)
{
	IOWR_32DIRECT(DE10_LITE_SSD_IP_0_BASE, 4 + (display << 2), value);
}
