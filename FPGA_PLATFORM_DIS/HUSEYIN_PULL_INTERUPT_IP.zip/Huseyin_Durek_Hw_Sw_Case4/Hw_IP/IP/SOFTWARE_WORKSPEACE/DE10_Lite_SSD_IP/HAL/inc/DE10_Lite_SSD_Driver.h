/*!
 * \file       DE10_Lite_SSD_Driver.h
 * \details    Drivers for the Seven Segment Display component for use with the DE10-Lite board.
 * \author     Linus Eriksson
 * \author     Jens Lind
 * \version    2.0
 * \date       2017-2021
 * \copyright  AGSTU AB
 */

#ifndef _DE10_LITE_SSD_DRIVER_H_
#define _DE10_LITE_SSD_DRIVER_H_

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*! \defgroup display_masks Display toggle masks
 *  \brief Use these masks with function ssd_enable to improve readability.
 *  @{
 */
#define HEX0_ENABLE_ID 0x01
#define HEX1_ENABLE_ID 0x02
#define HEX2_ENABLE_ID 0x04
#define HEX3_ENABLE_ID 0x08
#define HEX4_ENABLE_ID 0x10
#define HEX5_ENABLE_ID 0x20
#define HEX_ALL_ENABLE 0x3f
///@}

/*! \defgroup display_indices Display write index
 *  \brief Use these indices with function ssd_write to improve readability.
 *  @{
 */
#define HEX0_DATA_ID 0x00
#define HEX1_DATA_ID 0x01
#define HEX2_DATA_ID 0x02
#define HEX3_DATA_ID 0x03
#define HEX4_DATA_ID 0x04
#define HEX5_DATA_ID 0x05
///@}

//! Special value for writing a decimal point to display
#define HEX_DECIMAL 0x80

/*! \brief Function used to toggle displays on or off.
    \param displays Any combination of HEX ID values to specify which displays should be enabled or disabled.
           HEX_ALL_ENABLE can be used to enable all displays and value of 0 turns all off.
*/
extern void ssd_enable(uint8_t displays);

/*! \brief Function used to write a hexadecimal value to a specific display.
           Example: To display F in first display use ssd_write(HEX0_DATA_ID, 0xf).
    \param display Defines which display to write to, see "Display write index".
    \param value Hexadecimal value (0 - F) to write to the display.
*/
extern void ssd_write(uint8_t display, uint8_t value);

#ifdef __cplusplus
}
#endif

#endif // _DE10_LITE_SSD_DRIVER_H_